<!-- GETTING STARTED -->
## Getting Started

Clone this repo, and open jupyter notebook.

### Prerequisites
All the libraries and frameworks used in the notebook should be available on the
system where its being run
